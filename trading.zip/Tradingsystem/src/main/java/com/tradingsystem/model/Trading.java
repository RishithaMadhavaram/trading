package com.tradingsystem.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table
public class Trading {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int tid;
	String customer_name;
	String stock_name;
	int stock_quantity;
	int stock_price;
	int stock_lp;
	int bank_accno;
	int trading_accno;
	int pan;
	int aadhar;
	String notes;
	int ph_no;
	public Trading() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Trading(int tid, String customer_name, String stock_name, int stock_quantity, int stock_price, int stock_lp,
			int bank_accno, int trading_accno, int pan, int aadhar, String notes, int ph_no) {
		super();
		this.tid = tid;
		this.customer_name = customer_name;
		this.stock_name = stock_name;
		this.stock_quantity = stock_quantity;
		this.stock_price = stock_price;
		this.stock_lp = stock_lp;
		this.bank_accno = bank_accno;
		this.trading_accno = trading_accno;
		this.pan = pan;
		this.aadhar = aadhar;
		this.notes = notes;
		this.ph_no = ph_no;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getStock_name() {
		return stock_name;
	}
	public void setStock_name(String stock_name) {
		this.stock_name = stock_name;
	}
	public int getStock_quantity() {
		return stock_quantity;
	}
	public void setStock_quantity(int stock_quantity) {
		this.stock_quantity = stock_quantity;
	}
	public int getStock_price() {
		return stock_price;
	}
	public void setStock_price(int stock_price) {
		this.stock_price = stock_price;
	}
	public int getStock_lp() {
		return stock_lp;
	}
	public void setStock_lp(int stock_lp) {
		this.stock_lp = stock_lp;
	}
	public int getBank_accno() {
		return bank_accno;
	}
	public void setBank_accno(int bank_accno) {
		this.bank_accno = bank_accno;
	}
	public int getTrading_accno() {
		return trading_accno;
	}
	public void setTrading_accno(int trading_accno) {
		this.trading_accno = trading_accno;
	}
	public int getPan() {
		return pan;
	}
	public void setPan(int pan) {
		this.pan = pan;
	}
	public int getAadhar() {
		return aadhar;
	}
	public void setAadhar(int aadhar) {
		this.aadhar = aadhar;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public int getPh_no() {
		return ph_no;
	}
	public void setPh_no(int ph_no) {
		this.ph_no = ph_no;
	}
	@Override
	public String toString() {
		return "Trading [tid=" + tid + ", customer_name=" + customer_name + ", stock_name=" + stock_name
				+ ", stock_quantity=" + stock_quantity + ", stock_price=" + stock_price + ", stock_lp=" + stock_lp
				+ ", bank_accno=" + bank_accno + ", trading_accno=" + trading_accno + ", pan=" + pan + ", aadhar="
				+ aadhar + ", notes=" + notes + ", ph_no=" + ph_no + "]";
	}
	
}
