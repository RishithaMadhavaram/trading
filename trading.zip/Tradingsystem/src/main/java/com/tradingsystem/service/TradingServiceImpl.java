package com.tradingsystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tradingsystem.dao.TradingRepo;
import com.tradingsystem.model.Trading;
@Service
public class TradingServiceImpl implements TradingService{
@Autowired
TradingRepo repo;
	@Override
	public Trading create(Trading trade) {
		// TODO Auto-generated method stub
		return repo.save(trade);
	}

	@Override
	public List<Trading> findAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Trading findById(int tid) {
		// TODO Auto-generated method stub
		return repo.findById(tid).get();
	}
   
}
