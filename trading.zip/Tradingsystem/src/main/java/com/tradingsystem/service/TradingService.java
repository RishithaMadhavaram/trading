package com.tradingsystem.service;

import java.util.List;

import com.tradingsystem.model.Trading;

public interface TradingService {
	public Trading create(Trading trade);
	public List<Trading> findAll();
	public Trading  findById(int tid);

}
