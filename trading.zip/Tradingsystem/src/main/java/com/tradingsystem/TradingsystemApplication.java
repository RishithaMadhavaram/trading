package com.tradingsystem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.tradingsystem.model.Trading;
import com.tradingsystem.service.TradingService;

@SpringBootApplication
public class TradingsystemApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(TradingsystemApplication.class, args);
	}
@Autowired 
TradingService service;
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Trading t = new Trading(1,"Deepak","Kumar",10,100,10,20,30,50,100,"Notes",12345);
		Trading t1 = new Trading(2,"Deepak","Kumar",10,100,10,20,30,50,100,"Notes",12345);
		service.create(t);
		service.create(t1);
	}

}
