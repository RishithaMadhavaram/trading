package com.tradingsystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tradingsystem.model.Trading;

public interface TradingRepo extends JpaRepository<Trading,Integer>{

}
